create view forward_days as
select `nums`.`num` AS `num`
from (select (((`cars`.`d1`.`digit` * 100) + (`cars`.`d2`.`digit` * 10)) + `cars`.`d3`.`digit`) AS `num`
      from `cars`.`digits` `d1`
               join `cars`.`digits` `d2`
               join `cars`.`digits` `d3`) `nums`
where (`nums`.`num` < 365)
order by `nums`.`num`;

