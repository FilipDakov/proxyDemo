create view digits as
select 0 AS `digit`
union
select 1 AS `1`
union
select 2 AS `2`
union
select 3 AS `3`
union
select 4 AS `4`
union
select 5 AS `5`
union
select 6 AS `6`
union
select 7 AS `7`
union
select 8 AS `8`
union
select 9 AS `9`;

